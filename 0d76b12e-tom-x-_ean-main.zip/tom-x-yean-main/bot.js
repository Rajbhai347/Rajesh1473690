'use strict';

const fs = require('fs');
const path = require('path');
const TelegramBot = require('node-telegram-bot-api');
const {
  startPairing,
  stopPairing,
  getActiveSessions,
  PAIRING_ROOT,
  normalizeNumber
} = require('./pair');

let token = process.env.TELEGRAM_BOT_TOKEN || process.env.BOT_TOKEN;
if (!token) {
  try {
    const tokenConfig = require('./token');
    const configuredToken = typeof tokenConfig === 'string' ? tokenConfig : tokenConfig?.token;
    if (configuredToken && configuredToken !== 'PASTE_TELEGRAM_BOT_TOKEN_HERE') token = configuredToken;
  } catch {}
}

if (typeof token === 'string') token = token.trim().replace(/^['"]|['"]$/g, '');

if (!token || token === 'PASTE_TELEGRAM_BOT_TOKEN_HERE') {
  console.warn('⚠️ Add your Telegram token to token.js or set TELEGRAM_BOT_TOKEN/BOT_TOKEN.');
  module.exports = null;
} else {
  const bot = new TelegramBot(token, { polling: true });
  const pending = new Map();
  const expiryTimers = new Map();
  const CHANNEL_URL = 'https://whatsapp.com/channel/0029Vb8tRmV1dAvz4wmoxE3r';
  const GROUP_URL = 'https://t.me/ApexMiniBotOfficial9';
  const GROUP_ID = '-1003727841064'; // official Telegram group (pairing works only here)
  const ADMIN_IDS = new Set(
    String(process.env.TELEGRAM_ADMIN_IDS || '')
      .split(',')
      .map((value) => value.trim())
      .filter(Boolean)
  );

// ===== FIX: Full country code → flag + name mapping =====
// Covers Bangladesh + most common WhatsApp pairing codes.
// If a code is still missing, it falls back to '🌍 UNKNOWN' so it never
// silently shows the wrong flag.
const COUNTRY_DATA = {
  // Bangladesh
  '880':  { flag: '🇧🇩', name: 'BD' },
  // India
  '91':   { flag: '🇮🇳', name: 'IN' },
  // Pakistan
  '92':   { flag: '🇵🇰', name: 'PK' },
  // Nepal
  '977':  { flag: '🇳🇵', name: 'NP' },
  // Sri Lanka
  '94':   { flag: '🇱🇰', name: 'LK' },
  // Myanmar
  '95':   { flag: '🇲🇲', name: 'MM' },
  // Indonesia
  '62':   { flag: '🇮🇩', name: 'ID' },
  // Malaysia
  '60':   { flag: '🇲🇾', name: 'MY' },
  // Singapore
  '65':   { flag: '🇸🇬', name: 'SG' },
  // Thailand
  '66':   { flag: '🇹🇭', name: 'TH' },
  // Philippines
  '63':   { flag: '🇵🇭', name: 'PH' },
  // Vietnam
  '84':   { flag: '🇻🇳', name: 'VN' },
  // Afghanistan
  '93':   { flag: '🇦🇫', name: 'AF' },
  // Maldives
  '960':  { flag: '🇲🇻', name: 'MV' },
  // Bhutan
  '975':  { flag: '🇧🇹', name: 'BT' },
  // China
  '86':   { flag: '🇨🇳', name: 'CN' },
  // Hong Kong
  '852':  { flag: '🇭🇰', name: 'HK' },
  // Macau
  '853':  { flag: '🇲🇴', name: 'MO' },
  // Taiwan
  '886':  { flag: '🇹🇼', name: 'TW' },
  // Japan
  '81':   { flag: '🇯🇵', name: 'JP' },
  // South Korea
  '82':   { flag: '🇰🇷', name: 'KR' },
  // USA / Canada / NANP
  '1':    { flag: '🇺🇸', name: 'US' },
  // United Kingdom
  '44':   { flag: '🇬🇧', name: 'GB' },
  // Germany
  '49':   { flag: '🇩🇪', name: 'DE' },
  // France
  '33':   { flag: '🇫🇷', name: 'FR' },
  // Italy
  '39':   { flag: '🇮🇹', name: 'IT' },
  // Spain
  '34':   { flag: '🇪🇸', name: 'ES' },
  // Netherlands
  '31':   { flag: '🇳🇱', name: 'NL' },
  // Belgium
  '32':   { flag: '🇧🇪', name: 'BE' },
  // Switzerland
  '41':   { flag: '🇨🇭', name: 'CH' },
  // Austria
  '43':   { flag: '🇦🇹', name: 'AT' },
  // Poland
  '48':   { flag: '🇵🇱', name: 'PL' },
  // Turkey
  '90':   { flag: '🇹🇷', name: 'TR' },
  // Russia / Kazakhstan
  '7':    { flag: '🇷🇺', name: 'RU' },
  // Ukraine
  '380':  { flag: '🇺🇦', name: 'UA' },
  // Brazil
  '55':   { flag: '🇧🇷', name: 'BR' },
  // Mexico
  '52':   { flag: '🇲🇽', name: 'MX' },
  // Argentina
  '54':   { flag: '🇦🇷', name: 'AR' },
  // Colombia
  '57':   { flag: '🇨🇴', name: 'CO' },
  // Saudi Arabia
  '966':  { flag: '🇸🇦', name: 'SA' },
  // UAE
  '971':  { flag: '🇦🇪', name: 'AE' },
  // Qatar
  '974':  { flag: '🇶🇦', name: 'QA' },
  // Kuwait
  '965':  { flag: '🇰🇼', name: 'KW' },
  // Bahrain
  '973':  { flag: '🇧🇭', name: 'BH' },
  // Oman
  '968':  { flag: '🇴🇲', name: 'OM' },
  // Iraq
  '964':  { flag: '🇮🇶', name: 'IQ' },
  // Iran
  '98':   { flag: '🇮🇷', name: 'IR' },
  // Jordan
  '962':  { flag: '🇯🇴', name: 'JO' },
  // Egypt
  '20':   { flag: '🇪🇬', name: 'EG' },
  // Nigeria
  '234':  { flag: '🇳🇬', name: 'NG' },
  // South Africa
  '27':   { flag: '🇿🇦', name: 'ZA' },
  // Kenya
  '254':  { flag: '🇰🇪', name: 'KE' },
  // Ghana
  '233':  { flag: '🇬🇭', name: 'GH' },
  // Ethiopia
  '251':  { flag: '🇪🇹', name: 'ET' },
  // Tanzania
  '255':  { flag: '🇹🇿', name: 'TZ' },
  // Uganda
  '256':  { flag: '🇺🇬', name: 'UG' },
  // Somalia
  '252':  { flag: '🇸🇴', name: 'SO' },
  // Australia
  '61':   { flag: '🇦🇺', name: 'AU' },
  // New Zealand
  '64':   { flag: '🇳🇿', name: 'NZ' },
  // Sweden
  '46':   { flag: '🇸🇪', name: 'SE' },
  // Norway
  '47':   { flag: '🇳🇴', name: 'NO' },
  // Denmark
  '45':   { flag: '🇩🇰', name: 'DK' },
  // Finland
  '358':  { flag: '🇫🇮', name: 'FI' },
  // Ireland
  '353':  { flag: '🇮🇪', name: 'IE' },
  // Portugal
  '351':  { flag: '🇵🇹', name: 'PT' },
  // Greece
  '30':   { flag: '🇬🇷', name: 'GR' },
  // Israel
  '972':  { flag: '🇮🇱', name: 'IL' },
  // Lebanon
  '961':  { flag: '🇱🇧', name: 'LB' },
  // Yemen
  '967':  { flag: '🇾🇪', name: 'YE' },
  // Sudan
  '249':  { flag: '🇸🇩', name: 'SD' },
  // Libya
  '218':  { flag: '🇱🇾', name: 'LY' },
  // Tunisia
  '216':  { flag: '🇹🇳', name: 'TN' },
  // Algeria
  '213':  { flag: '🇩🇿', name: 'DZ' },
  // Morocco
  '212':  { flag: '🇲🇦', name: 'MA' },
  // Chile
  '56':   { flag: '🇨🇱', name: 'CL' },
  // Peru
  '51':   { flag: '🇵🇪', name: 'PE' },
  // Venezuela
  '58':   { flag: '🇻🇪', name: 'VE' },
  // Ecuador
  '593':  { flag: '🇪🇨', name: 'EC' },
  // Bolivia
  '591':  { flag: '🇧🇴', name: 'BO' },
  // Paraguay
  '595':  { flag: '🇵🇾', name: 'PY' },
  // Uruguay
  '598':  { flag: '🇺🇾', name: 'UY' },
  // Dominican Republic
  '1809': { flag: '🇩🇴', name: 'DO' },
  '1829': { flag: '🇩🇴', name: 'DO' },
  '1849': { flag: '🇩🇴', name: 'DO' },
  // Jamaica
  '1876': { flag: '🇯🇲', name: 'JM' },
  // Trinidad
  '1868': { flag: '🇹🇹', name: 'TT' },
  // Hungary
  '36':   { flag: '🇭🇺', name: 'HU' },
  // Czech Republic
  '420':  { flag: '🇨🇿', name: 'CZ' },
  // Slovakia
  '421':  { flag: '🇸🇰', name: 'SK' },
  // Romania
  '40':   { flag: '🇷🇴', name: 'RO' },
  // Bulgaria
  '359':  { flag: '🇧🇬', name: 'BG' },
  // Serbia
  '381':  { flag: '🇷🇸', name: 'RS' },
  // Croatia
  '385':  { flag: '🇭🇷', name: 'HR' },
  // Bosnia
  '387':  { flag: '🇧🇦', name: 'BA' },
  // Slovenia
  '386':  { flag: '🇸🇮', name: 'SI' },
  // Albania
  '355':  { flag: '🇦🇱', name: 'AL' },
  // North Macedonia
  '389':  { flag: '🇲🇰', name: 'MK' },
  // Montenegro
  '382':  { flag: '🇲🇪', name: 'ME' },
  // Kosovo
  '383':  { flag: '🇽🇰', name: 'XK' },
  // Moldova
  '373':  { flag: '🇲🇩', name: 'MD' },
  // Belarus
  '375':  { flag: '🇧🇾', name: 'BY' },
  // Estonia
  '372':  { flag: '🇪🇪', name: 'EE' },
  // Latvia
  '371':  { flag: '🇱🇻', name: 'LV' },
  // Lithuania
  '370':  { flag: '🇱🇹', name: 'LT' },
  // Georgia
  '995':  { flag: '🇬🇪', name: 'GE' },
  // Armenia
  '374':  { flag: '🇦🇲', name: 'AM' },
  // Azerbaijan
  '994':  { flag: '🇦🇿', name: 'AZ' },
  // Uzbekistan
  '998':  { flag: '🇺🇿', name: 'UZ' },
  // Kyrgyzstan
  '996':  { flag: '🇰🇬', name: 'KG' },
  // Tajikistan
  '992':  { flag: '🇹🇯', name: 'TJ' },
  // Turkmenistan
  '993':  { flag: '🇹🇲', name: 'TM' },
  // Cambodia
  '855':  { flag: '🇰🇭', name: 'KH' },
  // Laos
  '856':  { flag: '🇱🇦', name: 'LA' },
  // Mongolia
  '976':  { flag: '🇲🇳', name: 'MN' },
  // North Korea
  '850':  { flag: '🇰🇵', name: 'KP' },
  // Timor-Leste
  '670':  { flag: '🇹🇱', name: 'TL' },
  // Brunei
  '673':  { flag: '🇧🇳', name: 'BN' },
  // Papua New Guinea
  '675':  { flag: '🇵🇬', name: 'PG' },
  // Fiji
  '679':  { flag: '🇫🇯', name: 'FJ' },
  // Solomon Islands
  '677':  { flag: '🇸🇧', name: 'SB' },
  // Vanuatu
  '678':  { flag: '🇻🇺', name: 'VU' },
  // Samoa
  '685':  { flag: '🇼🇸', name: 'WS' },
  // Tonga
  '676':  { flag: '🇹🇴', name: 'TO' },
  // Kiribati
  '686':  { flag: '🇰🇮', name: 'KI' },
  // Tuvalu
  '688':  { flag: '🇹🇻', name: 'TV' },
  // Nauru
  '674':  { flag: '🇳🇷', name: 'NR' },
  // Palau
  '680':  { flag: '🇵🇼', name: 'PW' },
  // Marshall Islands
  '692':  { flag: '🇲🇭', name: 'MH' },
  // Micronesia
  '691':  { flag: '🇫🇲', name: 'FM' },
  // Cook Islands
  '682':  { flag: '🇨🇰', name: 'CK' },
  // Niue
  '683':  { flag: '🇳🇺', name: 'NU' },
  // French Polynesia
  '689':  { flag: '🇵🇫', name: 'PF' },
  // New Caledonia
  '687':  { flag: '🇳🇨', name: 'NC' },
  // Puerto Rico
  '1787': { flag: '🇵🇷', name: 'PR' },
  '1939': { flag: '🇵🇷', name: 'PR' },
  // US Virgin Islands
  '1340': { flag: '🇻🇮', name: 'VI' },
  // Guam
  '1671': { flag: '🇬🇺', name: 'GU' },
  // Cayman Islands
  '1345': { flag: '🇰🇾', name: 'KY' },
  // Bahamas
  '1242': { flag: '🇧🇸', name: 'BS' },
  // Barbados
  '1246': { flag: '🇧🇧', name: 'BB' },
  // Grenada
  '1473': { flag: '🇬🇩', name: 'GD' },
  // St. Lucia
  '1758': { flag: '🇱🇨', name: 'LC' },
  // St. Vincent
  '1784': { flag: '🇻🇨', name: 'VC' },
  // Antigua
  '1268': { flag: '🇦🇬', name: 'AG' },
  // Dominica
  '1767': { flag: '🇩🇲', name: 'DM' },
  // St. Kitts
  '1869': { flag: '🇰🇳', name: 'KN' },
  // Curaçao
  '599':  { flag: '🇨🇼', name: 'CW' },
  // Aruba
  '297':  { flag: '🇦🇼', name: 'AW' },
  // Belize
  '501':  { flag: '🇧🇿', name: 'BZ' },
  // Guatemala
  '502':  { flag: '🇬🇹', name: 'GT' },
  // El Salvador
  '503':  { flag: '🇸🇻', name: 'SV' },
  // Honduras
  '504':  { flag: '🇭🇳', name: 'HN' },
  // Nicaragua
  '505':  { flag: '🇳🇮', name: 'NI' },
  // Costa Rica
  '506':  { flag: '🇨🇷', name: 'CR' },
  // Panama
  '507':  { flag: '🇵🇦', name: 'PA' },
  // Haiti
  '509':  { flag: '🇭🇹', name: 'HT' },
  // Cuba
  '53':   { flag: '🇨🇺', name: 'CU' },
};

// ===== FIX: Smart country code detection =====
// Ekhon kono order-ei match hoy: age 3-digit code (880, 977, 960...),
// tarpor 2-digit (91, 94, 60...), tarpor 1-digit (1, 7...).
// Example: "919735009669" → age 91 try korbe → 🇮🇳 IN pabe, 
// ar "919" diye wrong flag ASHE NA anymore.
// Agge keno wrong hoyechilo: ager code-e sudhu `cleanNumber.slice(0,3)` 
// neya hoyechilo, tai "9197..." theke "919" neya hoyechilo — jeta map-e 
// chilo na, tai UNKNOWN dekhato. Ekhon proper prefix matching hocche.
const detectCountryCode = (cleanNumber) => {
  // longest-first search ensures 880 is matched before 88
  const candidates = [3, 2, 1];
  for (const len of candidates) {
    const prefix = cleanNumber.slice(0, len);
    if (COUNTRY_DATA[prefix]) {
      return prefix;
    }
  }
  return null;
};

const getCountryFlag = (countryCode) => {
  const info = COUNTRY_DATA[countryCode];
  return info ? info.flag : '🌍';
};

const getCountryName = (countryCode) => {
  const info = COUNTRY_DATA[countryCode];
  return info ? info.name : 'UNKNOWN';
};


  function isGroupChat(msg) {
    return String(msg.chat?.id) === GROUP_ID;
  }

  function groupOnlyMarkup() {
    return {
      inline_keyboard: [
        [{ text: 'Official Group', url: GROUP_URL }],
        [{ text: '📢 WA Channel', url: CHANNEL_URL }]
      ]
    };
  }

  function sendGroupOnlyMessage(msg) {
    return bot.sendMessage(
      msg.chat.id,
      '🌸 <b>𝐆ʀᴏᴜᴘ ᴏɴʟʏ ғᴇᴀᴛᴜʀᴇ</b>\n\n👉 Tʜɪs ᴄᴏᴍᴍᴀɴᴅ ᴡᴏʀᴋs ᴏɴʟʏ ɪɴ ᴛʜᴇ ᴏғғɪᴄɪᴀʟ ɢʀᴏᴜᴘ.\nᑕʟɪᴄᴋ ʙᴇʟᴏᴡ ᴛᴏ ᴊᴏɪɴ ᴀɴᴅ ᴜsᴇ <code>/pair</code> ᴛʜᴇʀᴇ.',
      replyOptions(msg, { reply_markup: groupOnlyMarkup() })
    );
  }

  function isAdmin(msg) {
    if (!ADMIN_IDS.size) return true;
    return ADMIN_IDS.has(String(msg.from?.id)) || ADMIN_IDS.has(String(msg.chat?.id));
  }

  function replyOptions(msg, extra = {}) {
    return {
      reply_to_message_id: msg.message_id,
      parse_mode: 'HTML',
      ...extra
    };
  }

  function channelMarkup(includeCopyCode = false, code = '') {
    const rows = [];
    if (includeCopyCode && code) {
      rows.push([{ text: `📋 Copy Code: ${code}`, copy_text: { text: String(code).replace(/-/g, '') } }]);
    }
    rows.push([{ text: '📢 WA Channel', url: CHANNEL_URL }]);
    return { inline_keyboard: rows };
  }

  function cleanNumber(value) {
    return normalizeNumber(value);
  }

  function sessionDir(number) {
    return path.join(PAIRING_ROOT, `${number}@s.whatsapp.net`);
  }

  function uptimeText() {
    const total = Math.floor(process.uptime());
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor((total % 3600) / 60);
    const seconds = total % 60;
    return `${hours}h ${minutes}m ${seconds}s`;
  }

  bot.onText(/^\/start(?:@\w+)?$/i, (msg) => {
    if (!isGroupChat(msg)) return sendGroupOnlyMessage(msg);
    const text =
      '✨ <b>𝐀𝐏𝐄𝐗 𝐌𝐈𝐍𝐈 𝐁𝐎𝐓 𝐏ᴀɪʀ</b>\n\n' +
      '🍉 𝐅ᴀsᴛ ᴀɴᴅ sᴇᴄᴜʀᴇ ᴡʜᴀᴛsᴀᴘᴘ ᴘᴀɪʀɪɴɢ ʙᴏᴛ.\n\n' +
      '📌 ᑌsᴇ: <code>/pair 8801XXXXXXXXX</code>\n' +
      '📊 𝐂ʜᴇᴄᴋ ʙᴏᴛ sᴛᴀᴛᴜs: <code>/status</code>\n' +
      '🏓 𝐂ʜᴇᴄᴋ ʟᴀᴛᴇɴᴄʏ: <code>/ping</code>';
    return bot.sendMessage(msg.chat.id, text, replyOptions(msg, {
      reply_markup: channelMarkup()
    }));
  });

  bot.onText(/^\/ping(?:@\w+)?$/i, async (msg) => {
    const startedAt = Date.now();
    const sent = await bot.sendMessage(msg.chat.id, '🏓 <b>Pᴏɴɢ!</b>', replyOptions(msg));
    const latency = Date.now() - startedAt;
    try {
      await bot.editMessageText(
        `🏓 <b>Pᴏɴɢ!</b>\n⚡ <b>${latency}ms</b>`,
        {
          chat_id: msg.chat.id,
          message_id: sent.message_id,
          parse_mode: 'HTML',
          reply_markup: channelMarkup()
        }
      );
    } catch {
      await bot.sendMessage(msg.chat.id, `🏓 <b>Pᴏɴɢ!</b>\n⚡ <b>${latency}ms</b>`, replyOptions(msg, {
        reply_markup: channelMarkup()
      }));
    }
  });

  bot.onText(/^\/status(?:@\w+)?$/i, async (msg) => {
    const sessions = getActiveSessions();
    const memory = Math.round(process.memoryUsage().rss / 1024 / 1024);
    const statusText =
      '📊 <b>𝐁ᴏᴛ Տᴛᴀᴛᴜs</b>\n' +
      '⚡ <b>𝐏ᴏᴡᴇʀᴇᴅ ʙʏ 𝐀𝐏𝐄𝐗 𝐌𝐈𝐍𝐈 𝐁𝐎𝐓</b>\n\n' +
      `⏱️ <b>𝐔ᴘᴛɪᴍᴇ:</b> ${uptimeText()}\n` +
      `💾 <b>𝐌ᴇᴍᴏʀʏ:</b> ${memory} MB\n` +
      `📡 <b>𝐀ᴄᴛɪᴠᴇ Տᴇssɪᴏɴs:</b> ${sessions.length}\n` +
      '🟢 <b>Oɴʟɪɴᴇ</b>\n' +
      `🖥️ <b>𝐏ʟᴀᴛғᴏʀᴍ:</b> ${process.platform}\n` +
      `📦 <b>𝐍ᴏᴅᴇ.ᴊs:</b> ${process.version}`;
    return bot.sendMessage(msg.chat.id, statusText, replyOptions(msg, {
      reply_markup: channelMarkup()
    }));
  });

  bot.onText(/^\/pair(?:@\w+)?(?:\s+(.+)|([+0-9][0-9\s-]*))?$/i, async (msg, match) => {
    if (!isGroupChat(msg)) return sendGroupOnlyMessage(msg);
    if (!isAdmin(msg)) {
      return bot.sendMessage(msg.chat.id, '⛔ You are not allowed to pair sessions.', replyOptions(msg));
    }

    const raw = (match?.[1] || match?.[2])?.trim();
    if (!raw) {
      return bot.sendMessage(
        msg.chat.id,
        '📱 <b>𝐏ʟᴇᴀsᴇ ᴘʀᴏᴠɪᴅᴇ ᴀ ᴘʜᴏɴᴇ ɴᴜᴍʙᴇʀ.</b>\n\n𝐄xᴀᴍᴘʟᴇ: <code>/pair 8801791903810</code>\nIɴᴄʟᴜᴅᴇ ᴛʜᴇ ᴄᴏᴜɴᴛʀʏ ᴄᴏᴅᴇ ᴡɪᴛʜᴏᴜᴛ ᴛʜᴇ ʟᴏᴀᴅɪɴɢ ᴢᴇʀᴏ.',
        replyOptions(msg, { reply_markup: channelMarkup() })
      );
    }

    const digitsOnly = String(raw).replace(/\D/g, '');
    if (digitsOnly.startsWith('0')) {
      return bot.sendMessage(msg.chat.id, '❌ <b>Do not start with 0.</b>\n\nInclude your country code, for example: <code>/pair 8801XXXXXXXXX</code>', replyOptions(msg, { reply_markup: channelMarkup() }));
    }
    if (!/^\d{7,15}$/.test(digitsOnly)) {
      return bot.sendMessage(msg.chat.id, '❌ <b>Invalid number format.</b>\n\nExample: <code>/pair +8801791903810</code>\nInclude your country code.', replyOptions(msg, { reply_markup: channelMarkup() }));
    }

    let number;
    try {
      number = cleanNumber(raw);
    } catch {
      return bot.sendMessage(msg.chat.id, '❌ Invalid phone number. Use country code and digits only.', replyOptions(msg));
    }

    const countryCode = detectCountryCode(number) || number.slice(0, 3);
    const countryInfo = COUNTRY_DATA[countryCode] || { flag: '🌍', name: 'UNKNOWN' };
    if (pending.has(number) || fs.existsSync(path.join(sessionDir(number), 'creds.json'))) {
      return bot.sendMessage(
        msg.chat.id,
        `✅ <b>𝐀ʟʀᴇᴀᴅʏ ᴄᴏɴɴᴇᴄᴛᴇᴅ!</b>\n\n📱 <b>𝐍ᴜᴍʙᴇʀ:</b> +${number}\n${countryInfo.flag} <b>${countryInfo.name}</b> (+${countryCode})\n\n🤖 𝐓ʜɪs ɴᴜᴍʙᴇʀ ᴀʟʀᴇᴀᴅʏ ʜᴀs ᴀ sᴇssɪᴏɴ. ᑌsᴇ <code>/unpair ${number}</code> ᖴɪʀsᴛ ɪғ ʏᴏᴜ ɴᴇᴇᴅ ᴛᴏ ʀᴇᴘʟᴀᴄᴇ ɪᴛ.`,
        replyOptions(msg, { reply_markup: channelMarkup() })
      );
    }

    pending.set(number, { chatId: msg.chat.id, messageId: msg.message_id, createdAt: Date.now(), countryCode });
    let pairMessageId = null;
    try {
      const waiting = await bot.sendMessage(
        msg.chat.id,
        `⌛ <b>𝐑ᴇǫᴜᴇsᴛɪɴɢ ᴘᴀɪʀɪɴɢ...</b>\n\n📱 <b>𝐍ᴜᴍʙᴇʀ:</b> +${number}\n${countryInfo.flag} ${countryInfo.name} (+${countryCode})\n\n🔒 𝐏ʟᴇᴀsᴇ ᴡᴀɪᴛ ᴀ ᴍᴏᴍᴇɴᴛs...`,
        replyOptions(msg)
      );

      await startPairing(number, {
        onPairingCode: async (code) => {
          const pairText =
            '🔐 <b>𝐏ᴀɪʀ ᴄᴏᴅᴇ ʀᴇᴀᴅʏ</b>\n' +
            `📱 <b>𝐍ᴜᴍʙᴇʀ:</b> +${number}\n${countryInfo.flag} ${countryInfo.name} (+${countryCode})\n\n` +
            `╭────〔 🛡️ᑕᴏᴅᴇ 〕────╮\n│ <code>${code}</code>\n╰────────────────────╯\n\n` +
            '📌 <b>𝐇ᴏᴡ ᴛᴏ ᴜsᴇ:</b>\n' +
            '1. 𝐖ʜᴀᴛsᴀᴘᴘ → Տᴇᴛᴛɪɴɢs → ᒪɪɴᴋᴇᴅ ᗪᴇᴠɪᴄᴇs\n' +
            '2. ᒪɪɴᴋ ᴀ ᗪᴇᴠɪᴄᴇ → ᗴɴᴛᴇʀ ᑕᴏᴅᴇ\n\n' +
            '⏰ 𝐄ɴᴛᴇʀ Tʜᴇ ᑕᴏᴅᴇ ᗩs Տᴏᴏɴ ᗩs 𝐏ᴏssɪʙʟᴇ.';
          await bot.deleteMessage(msg.chat.id, waiting.message_id).catch(() => {});
          const pairMessage = await bot.sendMessage(msg.chat.id, pairText, replyOptions(msg, {
            reply_markup: channelMarkup(true, code)
          }));
          pairMessageId = pairMessage.message_id;
          const timer = setTimeout(async () => {
            expiryTimers.delete(number);
            if (!getActiveSessions().some((session) => session.number === number && session.connected)) {
              await bot.deleteMessage(msg.chat.id, pairMessage.message_id).catch(() => {});
              await stopPairing(number, true).catch(() => {});
              pending.delete(number);
              await bot.sendMessage(msg.chat.id, `⌛ <b>𝐏ᴀɪʀɪɴɢ ᴛɪᴍᴇᴅ 𝐎ᴜᴛ</b>\n\n📱 <b>𝐍ᴜᴍʙᴇʀ:</b> +${number}\n\n🔐 𝐓ʜᴇ ᴘᴀɪʀ ᴄᴏᴅᴇ ᴇxᴘɪʀᴇᴅ ᗩғᴛᴇʀ 1 ᴍɪɴᴜᴛᴇ ᗷᴇᴄᴀᴜsᴇ ᴛʜᴇ ɴᴜᴍʙᴇʀ ᴡᴀs ɴᴏᴛ ᑕᴏɴɴᴇᴄᴛᴇᴅ ɪɴ ᴛɪᴍᴇ.\n\n🔄 Տᴇɴᴅ <code>/pair ${number}</code> ᗩɢᴀɪɴ ᴛᴏ 𝐑ᴇǫᴜᴇsᴛ ᴀ 𝐍ᴇᴡ ᑕᴏᴅᴇ.`, replyOptions(msg, { reply_markup: channelMarkup() })).catch(() => {});
            }
          }, 60 * 1000);
          expiryTimers.set(number, timer);
        },
        onConnected: async () => {
          pending.delete(number);
          if (pairMessageId) {
            await bot.deleteMessage(msg.chat.id, pairMessageId).catch(() => {});
            pairMessageId = null;
          }
          const expiryTimer = expiryTimers.get(number);
          if (expiryTimer) clearTimeout(expiryTimer);
          expiryTimers.delete(number);
          await bot.sendMessage(
            msg.chat.id,
            '❤️‍🔥 <b>BOT CONNECTED!</b>\n\n' +
            '🪄 <b>THIS NUMBER IS NOW CONNECTED!</b>\n\n' +
            `📱 <b>NUMBER:</b> +${number}\n${countryInfo.flag} <b>${countryInfo.name}</b> (+${countryCode})`,
            replyOptions(msg, { reply_markup: channelMarkup() })
          );
        },
        onLoggedOut: async () => {
          pending.delete(number);
          if (pairMessageId) {
            await bot.deleteMessage(msg.chat.id, pairMessageId).catch(() => {});
            pairMessageId = null;
          }
          const expiryTimer = expiryTimers.get(number);
          if (expiryTimer) clearTimeout(expiryTimer);
          expiryTimers.delete(number);
          await bot.sendMessage(
            msg.chat.id,
            `⚠️ <b>${number}</b> logged out or has an invalid session.`,
            replyOptions(msg, { reply_markup: channelMarkup() })
          );
        }
      });
    } catch (error) {
      pending.delete(number);
      if (pairMessageId) await bot.deleteMessage(msg.chat.id, pairMessageId).catch(() => {});
      const expiryTimer = expiryTimers.get(number);
      if (expiryTimer) clearTimeout(expiryTimer);
      expiryTimers.delete(number);
      await bot.sendMessage(msg.chat.id, `❌ <b>Pairing failed:</b> ${error.message}`, replyOptions(msg));
    }
  });

  bot.onText(/^\/unpair(?:@\w+)?(?:\s+(.+))?$/i, async (msg, match) => {
    if (!isAdmin(msg)) return bot.sendMessage(msg.chat.id, '⛔ Not allowed.', replyOptions(msg));
    let number;
    try {
      number = cleanNumber(match?.[1]);
    } catch {
      return bot.sendMessage(msg.chat.id, 'ᑌsᴀɢᴇ: <code>/unpair 8801XXXXXXXXX</code>', replyOptions(msg));
    }
    try {
      await stopPairing(number, true);
      pending.delete(number);
      return bot.sendMessage(msg.chat.id, `✅ Session <b>${number}</b> removed.`, replyOptions(msg, {
        reply_markup: channelMarkup()
      }));
    } catch (error) {
      return bot.sendMessage(msg.chat.id, `❌ Unpair failed: ${error.message}`, replyOptions(msg));
    }
  });

  bot.onText(/^\/(?:sessions|session)(?:@\w+)?$/i, async (msg) => {
    if (!isAdmin(msg)) return bot.sendMessage(msg.chat.id, '⛔ Not allowed.', replyOptions(msg));
    const sessions = getActiveSessions();
    const text = sessions.length
      ? sessions.map((session) => `• ${session.number} — ${session.connected ? 'connected' : 'starting'}`).join('\n')
      : 'No active sessions.';
    return bot.sendMessage(msg.chat.id, `📡 <b>ACTIVE SESSIONS</b>\n\n${text}`, replyOptions(msg, {
      reply_markup: channelMarkup()
    }));
  });

  bot.on('polling_error', (error) => console.error('[telegram polling]', error.message));
  console.log('✅ Telegram pairing control-plane started.');
  module.exports = bot;
}
