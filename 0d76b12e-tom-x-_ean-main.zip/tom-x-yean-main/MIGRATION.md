# KnightBot Mini — Multi-Session Migration

This repository now uses the 1st bot’s control-plane pattern while preserving the 2nd bot’s command and database layers. WhatsApp sessions are isolated by phone number under `database/sessions/<number>@s.whatsapp.net/`; no account shares another account’s auth state.

## Runtime structure

| Path | Purpose |
|---|---|
| `index.js` | Starts the runtime and autoloads persisted sessions. |
| `pair.js` | Creates, reconnects, isolates, and stops one WhatsApp session. |
| `autoload.js` | Restores all paired sessions after a restart in controlled batches. |
| `bot.js` | Telegram `/pair`, `/unpair`, `/sessions`, and `/start` control-plane. |
| `handler.js` | Existing command execution, group checks, admin checks, and event helpers. |
| `commands/` | Active command modules loaded by `utils/commandLoader.js`. |
| `utils/` | Shared command and feature helpers. |
| `database/` | Shared moderation/economy data and isolated auth sessions. |
| `config.js` | Bot defaults and owner configuration. |

## Environment

Set the token either in `token.js` as `module.exports = { token: 'YOUR_BOTFATHER_TOKEN' };` or with the `TELEGRAM_BOT_TOKEN`/`BOT_TOKEN` environment variable. Environment variables take precedence. `TELEGRAM_ADMIN_IDS` may contain a comma-separated list of Telegram user/chat IDs; if it is empty, the Telegram control-plane permits pairing commands for compatibility with the original repository. Do not commit tokens, `.env` files, or session directories.

## Pairing

Send `/pair 8801XXXXXXXXX` to the Telegram bot. A separate Baileys auth directory is created for that number. Existing paired directories are autoloaded on startup. `/unpair 8801XXXXXXXXX` disconnects the active session and removes its auth directory. `/sessions` lists active sessions.

## Cleanup policy

The migration removed the previous single-session startup path from `index.js` and did not delete command modules solely by filename. A command is retained unless it is proven unused or broken because the loader and menu system discover commands dynamically. Runtime secrets, auth folders, logs, caches, and `node_modules` must remain outside the source archive.

## Validation

The migrated entrypoint, pairing manager, autoload module, Telegram control-plane, handler, and command loader pass `node --check`. Run `npm install --legacy-peer-deps`, put the BotFather token in `token.js` or set the environment variables, and then run `npm start`. Railway should use `node index.js` as its Start Command; the included Procfile already contains this command.
