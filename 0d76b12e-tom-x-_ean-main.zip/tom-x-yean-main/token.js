'use strict';

// Paste the token received from @BotFather between the quotes below.
// Never publish this file or commit the real token to GitHub.
module.exports = {
  token: '8909987179:AAFdl0nntmjwqjuoTRxwljy9HPPutl9t-PU'
};
